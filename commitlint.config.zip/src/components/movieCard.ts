// src/components/movieCard.ts

import { Movie } from '../models/movie';
import { toggleFavorite } from '../utils/favorites';
import { createElement } from '../utils/domHelpers';

export function renderMovieCard(movie: Movie): HTMLElement {
  // <div class="col-lg-3 col-md-4 col-12 p-2">
  const colDiv = createElement('div', ['col-lg-3', 'col-md-4', 'col-12', 'p-2']);

  // <div class="card shadow-sm position-relative">
  const cardDiv = createElement('div', ['card', 'shadow-sm', 'position-relative']);

  // <img src="..." />
  const img = document.createElement('img');
  img.src = movie.posterUrl;
  img.classList.add('card-img-top'); // можно добавить, если нужно одинаковый стиль
  img.alt = movie.title;

  // SVG-сердечко в правом верхнем углу ( покажем полностью залитое или полупрозрачное )
  const svgHeart = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svgHeart.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
  svgHeart.setAttribute('stroke', movie.isFavorite ? 'red' : 'red');
  svgHeart.setAttribute('fill', movie.isFavorite ? 'red' : '#ff000078');
  svgHeart.setAttribute('width', '50');
  svgHeart.setAttribute('height', '50');
  svgHeart.setAttribute('viewBox', '0 -2 18 22');
  svgHeart.classList.add('bi', 'bi-heart-fill', 'position-absolute', 'p-2');
  // Обработчик клика по сердечку
  svgHeart.addEventListener('click', () => {
    const nowFav = toggleFavorite(movie.id);
    if (nowFav) {
      svgHeart.setAttribute('fill', 'red');
    } else {
      svgHeart.setAttribute('fill', '#ff000078');
    }
  });
  // Позиционируем сердечко: правый верхний угол
  svgHeart.style.top = '0';
  svgHeart.style.right = '0';
  svgHeart.style.cursor = 'pointer';

  // <div class="card-body">…</div>
  const bodyDiv = createElement('div', ['card-body']);

  // <p class="card-text truncate">…overview…</p>
  const descP = createElement('p', ['card-text', 'truncate'], movie.overview);

  // <div class="d-flex justify-content-between align-items-center">
  const infoWrap = createElement('div', ['d-flex', 'justify-content-between', 'align-items-center']);
  // <small class="text-muted">releaseDate</small>
  const dateText = createElement('small', ['text-muted'], movie.releaseDate);

  infoWrap.appendChild(dateText);
  bodyDiv.appendChild(descP);
  bodyDiv.appendChild(infoWrap);

  cardDiv.appendChild(img);
  cardDiv.appendChild(svgHeart);
  cardDiv.appendChild(bodyDiv);
  colDiv.appendChild(cardDiv);

  return colDiv;
}
