// src/components/randomBanner.ts

import { Movie } from '../models/movie';

export function renderRandomBanner(movie: Movie): void {
  const titleEl = document.getElementById('random-movie-name') as HTMLHeadingElement;
  const descEl = document.getElementById('random-movie-description') as HTMLParagraphElement;

  if (!titleEl || !descEl) return;

  titleEl.textContent = movie.title;
  // Если текст слишком длинный, можно обрезать до 300 символов, как в верстке
  descEl.textContent =
    movie.overview.length > 300 ? movie.overview.slice(0, 300) + '…' : movie.overview;
}
