// src/main.ts

import 'bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import './styles/styles.css';

import {
  getPopularMovies,
  getTopRatedMovies,
  getUpcomingMovies,
} from './api/movieApi';
import { getFavoriteIds } from './utils/favorites';
import { mapResultsToMovies } from './utils/mapper';
import { renderRandomBanner } from './components/randomBanner';
import { Paginator } from './components/pagination';
import { initSearch } from './components/searchForm';
import { getMovieDetails } from './api/movieApi';

// --------------- helper для отображения избранных в offcanvas ---------------

async function renderFavoritesInOffcanvas() {
  const favContainer = document.getElementById('favorite-movies') as HTMLElement;
  if (!favContainer) return;

  favContainer.innerHTML = ''; // очищаем раньше сгенерированный контент

  const favIds = Array.from(getFavoriteIds());
  if (favIds.length === 0) {
    favContainer.textContent = 'Нет избранных фильмов.';
    return;
  }

  // Для каждого id получаем детали через getMovieDetails(id)
  for (const id of favIds) {
    try {
      const raw = await getMovieDetails(id);
      // Предполагаем, что mapper умеет из raw сделать Movie. isFavorite всегда true
      const movie = mapResultsToMovies([raw], new Set(favIds))[0];
      // Рендерим карточку (код movieCard уже создаёт <div class="col-..."><div class="card">…</div></div>)
      const cardEl = await import('./components/movieCard').then((m) => m.renderMovieCard(movie));
      favContainer.appendChild(cardEl);
    } catch (err) {
      console.error(`Не удалось загрузить детали фильма ${id}`, err);
    }
  }
}

// --------------- main ---------------

async function main() {
  // 1) Инициализируем пагинатор для "popular"
  const paginator = new Paginator('film-container', 'load-more', (page) =>
    getPopularMovies(page)
  );
  await paginator.init();

  // 2) Рендерим случайный баннер из первой страницы popular
  try {
    const resp = await getPopularMovies(1);
    const favIds = getFavoriteIds();
    const mapped = mapResultsToMovies(resp.results, favIds);
    const randomIndex = Math.floor(Math.random() * mapped.length);
    const randomMovie = mapped[randomIndex];
    renderRandomBanner(randomMovie);

    // Если хотите динамически поменять фон секции: 
    // const bannerSection = document.getElementById('random-movie') as HTMLElement;
    // if (bannerSection && randomMovie.posterUrl) {
    //   bannerSection.style.backgroundImage = `url(${randomMovie.posterUrl})`;
    //   bannerSection.style.backgroundSize = 'cover';
    //   bannerSection.style.backgroundPosition = 'center';
    // }
  } catch (err) {
    console.error('Ошибка при рендере рандомного баннера:', err);
  }

  // 3) Переключение категорий по радио-кнопкам (id="popular", "upcoming", "top_rated")
  const popularRadio = document.getElementById('popular') as HTMLInputElement;
  const upcomingRadio = document.getElementById('upcoming') as HTMLInputElement;
  const topRatedRadio = document.getElementById('top_rated') as HTMLInputElement;

  if (popularRadio) {
    popularRadio.addEventListener('change', async () => {
      if (popularRadio.checked) {
        await paginator.switchFetchFn((page) => getPopularMovies(page));
      }
    });
  }
  if (upcomingRadio) {
    upcomingRadio.addEventListener('change', async () => {
      if (upcomingRadio.checked) {
        await paginator.switchFetchFn((page) => getUpcomingMovies(page));
      }
    });
  }
  if (topRatedRadio) {
    topRatedRadio.addEventListener('change', async () => {
      if (topRatedRadio.checked) {
        await paginator.switchFetchFn((page) => getTopRatedMovies(page));
      }
    });
  }

  // 4) Инициализируем поиск
  initSearch(paginator);

  // 5) Рендерим избранные фильмы в offcanvas при каждом открытии панели
  const offcanvasEl = document.getElementById('offcanvasRight') as HTMLElement;
  if (offcanvasEl) {
    offcanvasEl.addEventListener('show.bs.offcanvas', () => {
      renderFavoritesInOffcanvas();
    });
  }
}

main().catch((err) => console.error(err));
